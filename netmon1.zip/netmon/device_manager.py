import socket
import os
import re
import time
import logging
from datetime import datetime
from typing import Tuple

logger = logging.getLogger(__name__)

BACKUP_DIR = "./backups"


def check_online(ip: str, port: int = 22, timeout: int = 5) -> bool:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, port))
        sock.close()
        return result == 0
    except Exception:
        return False


def detect_device_type(ip: str, username: str, password: str, port: int = 22) -> str:
    """
    SSH into the device, read the banner/prompt, and classify it.
    Falls back to HTTPS probe for Palo Alto if SSH gives no clear answer.
    """
    detected = _detect_via_ssh(ip, username, password, port)
    if detected != "unknown":
        return detected
    return _detect_via_https(ip)


def _detect_via_ssh(ip: str, username: str, password: str, port: int) -> str:
    try:
        import paramiko

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            ip, port=port, username=username, password=password,
            timeout=10, banner_timeout=10, auth_timeout=10,
            look_for_keys=False, allow_agent=False,
        )

        shell = ssh.invoke_shell()
        shell.settimeout(8)
        time.sleep(2)

        output = ""
        while shell.recv_ready():
            output += shell.recv(4096).decode("utf-8", errors="ignore")

        ssh.close()
        lower = output.lower()

        if any(k in lower for k in ("pa-", "pan-os", "paloalto", "palo alto", "panorama")):
            return "palo_alto"
        if any(k in lower for k in ("nexus", "nx-os", "nxos")):
            return "cisco_nxos"
        if any(k in lower for k in ("ios-xe", "ios xe", "cat9k", "csr1000v")):
            return "cisco_xe"
        if any(k in lower for k in ("cisco ios", "cisco internetwork", "cisco systems")):
            return "cisco_ios"
        # Ambiguous Cisco prompt (e.g. lab devices with minimal banners)
        if re.search(r"[a-zA-Z0-9\-_]+[>#]\s*$", output):
            return "cisco_ios"

        return "unknown"

    except Exception as exc:
        logger.warning("SSH detection failed for %s: %s", ip, exc)
        return "unknown"


def _detect_via_https(ip: str) -> str:
    """Try Palo Alto XML API endpoint on HTTPS."""
    try:
        import urllib.request
        import ssl

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        url = f"https://{ip}/api/"
        req = urllib.request.urlopen(url, context=ctx, timeout=5)
        content = req.read().decode("utf-8", errors="ignore").lower()
        if any(k in content for k in ("paloalto", "pan", "globalprotect")):
            return "palo_alto"
    except Exception:
        pass
    return "unknown"


# ---------------------------------------------------------------------------
# Config backup helpers
# ---------------------------------------------------------------------------

def _netmiko_type(device_type: str) -> str:
    return {
        "cisco_ios": "cisco_ios",
        "cisco_nxos": "cisco_nxos",
        "cisco_xe": "cisco_xe",
        "palo_alto": "paloalto_panos",
    }.get(device_type, "cisco_ios")


def _backup_via_netmiko(ip: str, username: str, password: str, port: int,
                         device_type: str, command: str, read_timeout: int = 120) -> str:
    from netmiko import ConnectHandler

    conn_params = {
        "device_type": _netmiko_type(device_type),
        "host": ip,
        "username": username,
        "password": password,
        "port": port,
        "timeout": 30,
        "session_timeout": 120,
        "conn_timeout": 10,
    }
    with ConnectHandler(**conn_params) as conn:
        return conn.send_command(command, read_timeout=read_timeout)


def _backup_paloalto_api(ip: str, username: str, password: str) -> tuple:
    """
    Returns (config_xml: str, device_state_bytes: bytes).
    Saves a named snapshot first so the exported config matches exactly what was committed.
    """
    import urllib.request
    import urllib.parse
    import ssl

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    def api_get(url: str, timeout: int = 30) -> bytes:
        return urllib.request.urlopen(url, context=ctx, timeout=timeout).read()

    # 1. Obtain API key
    keygen_url = (
        f"https://{ip}/api/?type=keygen"
        f"&user={urllib.parse.quote(username)}"
        f"&password={urllib.parse.quote(password)}"
    )
    resp = api_get(keygen_url, timeout=15).decode()
    m = re.search(r"<key>(.*?)</key>", resp)
    if not m:
        raise RuntimeError("Palo Alto API key generation failed")
    api_key = urllib.parse.quote(m.group(1), safe="")

    # 2. Save named configuration snapshot with a date/time stamp
    snapshot_name = f"netmon_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xml"
    save_cmd = urllib.parse.quote(f"<save><config><to>{snapshot_name}</to></config></save>")
    save_url = f"https://{ip}/api/?type=op&cmd={save_cmd}&key={api_key}"
    save_resp = api_get(save_url, timeout=30).decode()
    if "error" in save_resp.lower() and 'status="success"' not in save_resp.lower():
        raise RuntimeError(f"Snapshot save failed: {save_resp[:200]}")

    # 3. Export the named configuration snapshot
    export_url = (
        f"https://{ip}/api/?type=export&category=configuration"
        f"&from={urllib.parse.quote(snapshot_name)}&key={api_key}"
    )
    config_xml = api_get(export_url, timeout=60).decode()

    # 4. Export device state (certificates, licenses, dynamic state — binary .tgz)
    device_state_url = f"https://{ip}/api/?type=export&category=device-state&key={api_key}"
    device_state_bytes = api_get(device_state_url, timeout=60)

    return config_xml, device_state_bytes


def backup_device(
    device_id: int, ip: str, username: str, password: str,
    port: int, device_type: str, device_name: str,
) -> Tuple[bool, str, str]:
    """
    Returns (success, filename, error_message).
    Palo Alto: produces a .zip containing config XML + device state .tgz.
    Cisco: produces a .cfg text file.
    """
    import io
    import zipfile

    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^\w\-]", "_", device_name)
    base = f"{safe}_{ip.replace('.', '_')}_{ts}"

    try:
        if device_type == "palo_alto":
            try:
                config_xml, device_state_bytes = _backup_paloalto_api(ip, username, password)
                filename = f"{base}.zip"
                filepath = os.path.join(BACKUP_DIR, filename)
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                    zf.writestr("config_snapshot.xml", config_xml)
                    zf.writestr("device_state.tgz", device_state_bytes)
                with open(filepath, "wb") as fh:
                    fh.write(buf.getvalue())
            except Exception:
                # SSH fallback — config only, no device state
                config = _backup_via_netmiko(ip, username, password, port,
                                              device_type, "show config running")
                filename = f"{base}.cfg"
                filepath = os.path.join(BACKUP_DIR, filename)
                with open(filepath, "w") as fh:
                    fh.write(config)

        elif device_type in ("cisco_ios", "cisco_xe", "cisco_nxos"):
            config = _backup_via_netmiko(ip, username, password, port,
                                          device_type, "show running-config")
            filename = f"{base}.cfg"
            filepath = os.path.join(BACKUP_DIR, filename)
            with open(filepath, "w") as fh:
                fh.write(config)

        else:
            raise RuntimeError(f"Cannot backup unknown device type: {device_type}")

        return True, filename, ""

    except Exception as exc:
        err = str(exc)
        logger.error("Backup failed for %s (%s): %s", device_name, ip, err)
        filename = f"{base}_ERROR.txt"
        filepath = os.path.join(BACKUP_DIR, filename)
        with open(filepath, "w") as fh:
            fh.write(f"BACKUP FAILED\n{err}\n")
        return False, filename, err
