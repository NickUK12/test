"""
Database migration — safe to run multiple times (fully idempotent).

Handles the upgrade from the original NetMon release (backup-only) to the
SNMP metrics + alerts version.  Run this before starting the updated server.
"""

import os
import sqlite3
import sys

DB_PATH = "./netmon.db"

if not os.path.exists(DB_PATH):
    print("No database found — a fresh one will be created when the server starts.")
    sys.exit(0)

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# ---------------------------------------------------------------------------
# 1. Add new columns to the devices table
# ---------------------------------------------------------------------------

NEW_DEVICE_COLUMNS = [
    # SNMP v2c column (kept for backwards compat, no longer used by app)
    ("snmp_community",      "TEXT     DEFAULT 'public'"),
    # SNMP v3 fields
    ("snmp_enabled",        "INTEGER  DEFAULT 1"),
    ("snmp_port",           "INTEGER  DEFAULT 161"),
    ("snmp_security_level", "TEXT     DEFAULT 'authPriv'"),
    ("snmp_username",       "TEXT     DEFAULT ''"),
    ("snmp_auth_protocol",  "TEXT     DEFAULT 'SHA'"),
    ("snmp_auth_password",  "TEXT     DEFAULT ''"),
    ("snmp_priv_protocol",  "TEXT     DEFAULT 'AES'"),
    ("snmp_priv_password",  "TEXT     DEFAULT ''"),
    # Denormalised poll metrics
    ("last_poll",           "DATETIME"),
    ("last_cpu_percent",    "REAL"),
    ("last_memory_percent", "REAL"),
    ("last_latency_ms",     "REAL"),
    ("last_uptime_seconds", "INTEGER"),
    ("last_interface_count","INTEGER"),
    ("last_interfaces_up",  "INTEGER"),
    ("sys_descr",           "TEXT"),
]

cur.execute("PRAGMA table_info(devices)")
existing_cols = {row[1] for row in cur.fetchall()}

added = []
for col_name, col_def in NEW_DEVICE_COLUMNS:
    if col_name not in existing_cols:
        cur.execute(f"ALTER TABLE devices ADD COLUMN {col_name} {col_def}")
        added.append(col_name)

if added:
    print(f"  devices table  — added columns: {', '.join(added)}")
else:
    print("  devices table  — already up to date")

# ---------------------------------------------------------------------------
# 2. Create snmp_metrics table
# ---------------------------------------------------------------------------

cur.execute("""
    CREATE TABLE IF NOT EXISTS snmp_metrics (
        id               INTEGER  PRIMARY KEY AUTOINCREMENT,
        device_id        INTEGER  NOT NULL REFERENCES devices(id),
        timestamp        DATETIME DEFAULT (datetime('now')),
        cpu_percent      REAL,
        memory_percent   REAL,
        latency_ms       REAL,
        uptime_seconds   INTEGER,
        interface_count  INTEGER,
        interfaces_up    INTEGER
    )
""")
print("  snmp_metrics   — OK")

# ---------------------------------------------------------------------------
# 3. Create alerts table
# ---------------------------------------------------------------------------

cur.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id          INTEGER  PRIMARY KEY AUTOINCREMENT,
        device_id   INTEGER  NOT NULL REFERENCES devices(id),
        timestamp   DATETIME DEFAULT (datetime('now')),
        severity    TEXT     NOT NULL,
        category    TEXT     NOT NULL,
        message     TEXT     NOT NULL,
        resolved    INTEGER  DEFAULT 0,
        resolved_at DATETIME
    )
""")
print("  alerts         — OK")

conn.commit()
conn.close()
print("\nMigration complete.")
