from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, Float,
    ForeignKey, Integer, String, Text, create_engine,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime
import os

DATABASE_URL = "sqlite:///./netmon.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

BACKUP_DIR = "./backups"
os.makedirs(BACKUP_DIR, exist_ok=True)


class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    ip = Column(String, nullable=False, unique=True)
    port = Column(Integer, default=22)
    username = Column(String, nullable=False)
    password = Column(String, nullable=False)
    # cisco_ios | cisco_nxos | cisco_xe | palo_alto | unknown
    device_type = Column(String, default="unknown")
    is_online = Column(Boolean, default=False)
    last_seen = Column(DateTime, nullable=True)
    last_backup = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # SNMP v3 settings
    snmp_enabled        = Column(Boolean, default=True)
    snmp_port           = Column(Integer, default=161)
    snmp_security_level = Column(String, default="authPriv")   # noAuthNoPriv | authNoPriv | authPriv
    snmp_username       = Column(String, default="")
    snmp_auth_protocol  = Column(String, default="SHA")        # MD5 | SHA | SHA256 | SHA512
    snmp_auth_password  = Column(String, default="")
    snmp_priv_protocol  = Column(String, default="AES")        # DES | AES | AES256
    snmp_priv_password  = Column(String, default="")

    # Denormalised latest poll values for fast dashboard reads
    last_poll = Column(DateTime, nullable=True)
    last_cpu_percent = Column(Float, nullable=True)
    last_memory_percent = Column(Float, nullable=True)
    last_latency_ms = Column(Float, nullable=True)
    last_uptime_seconds = Column(BigInteger, nullable=True)
    last_interface_count = Column(Integer, nullable=True)
    last_interfaces_up = Column(Integer, nullable=True)
    sys_descr = Column(Text, nullable=True)

    backups = relationship("Backup", back_populates="device", cascade="all, delete-orphan")
    metrics = relationship("SNMPMetric", back_populates="device", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="device", cascade="all, delete-orphan")


class Backup(Base):
    __tablename__ = "backups"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    filename = Column(String, nullable=False)
    size = Column(Integer, default=0)
    status = Column(String, default="success")  # success | failed
    error_message = Column(Text, nullable=True)

    device = relationship("Device", back_populates="backups")


class SNMPMetric(Base):
    __tablename__ = "snmp_metrics"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    cpu_percent = Column(Float, nullable=True)
    memory_percent = Column(Float, nullable=True)
    latency_ms = Column(Float, nullable=True)
    uptime_seconds = Column(BigInteger, nullable=True)
    interface_count = Column(Integer, nullable=True)
    interfaces_up = Column(Integer, nullable=True)

    device = relationship("Device", back_populates="metrics")


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    severity = Column(String, nullable=False)   # warning | critical
    category = Column(String, nullable=False)   # cpu | memory | latency | reachability | interface
    message = Column(Text, nullable=False)
    resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime, nullable=True)

    device = relationship("Device", back_populates="alerts")


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
