#!/bin/bash
# NetMon update script
# Run this inside the existing netmon directory to upgrade from the original
# release to the SNMP metrics + alerts version.
#
# Usage:  ./update.sh

set -e
cd "$(dirname "$0")"

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

info()  { echo -e "${GREEN}✓${NC} $1"; }
warn()  { echo -e "${YELLOW}!${NC} $1"; }
die()   { echo -e "${RED}✗${NC} $1"; exit 1; }

echo -e "\n${BOLD}NetMon — Update Script${NC}\n"

# ── Preflight checks ────────────────────────────────────────────────────────

[ -d "venv" ]        || die "No virtual environment found. Run ./setup.sh first."
[ -f "main.py" ]     || die "Not inside a NetMon directory (main.py missing)."

# Warn if a uvicorn process is already running
if pgrep -f "uvicorn main:app" > /dev/null 2>&1; then
    warn "NetMon appears to be running. Stop it before updating."
    read -rp "  Continue anyway? [y/N] " confirm
    [[ "$confirm" =~ ^[yY]$ ]] || { echo "Update cancelled."; exit 0; }
fi

# ── Backup the current database ─────────────────────────────────────────────

if [ -f "netmon.db" ]; then
    DB_BAK="netmon.db.bak_$(date +%Y%m%d_%H%M%S)"
    cp netmon.db "$DB_BAK"
    info "Database backed up to $DB_BAK"
else
    warn "No existing database found — nothing to back up (fresh start)"
fi

# ── Install new Python dependencies ─────────────────────────────────────────

source venv/bin/activate
info "Installing new dependencies…"
pip install -q --upgrade pip
pip install -q "puresnmp>=2.0.0"
info "Dependencies installed"

# ── Run database migration ───────────────────────────────────────────────────

info "Running database migration…"
python3 migrate.py

# ── Done ────────────────────────────────────────────────────────────────────

echo ""
echo -e "${BOLD}Update complete!${NC}"
echo ""
echo "What's new in this version:"
echo "  • SNMP polling — CPU %, memory %, uptime, latency, interface status"
echo "  • Health alerts — auto-created and auto-resolved on threshold breach"
echo "  • 30-day backup retention — old configs are automatically purged"
echo "  • Richer dashboard — metric bars, sparkline charts, alerts panel"
echo ""
echo "Start NetMon with:  ./start.sh"
echo ""
echo "Note: edit each device to set SNMPv3 credentials (username, auth/priv"
echo "      passwords and protocols). Existing devices will skip SNMP polling"
echo "      until credentials are configured."
