import asyncio
import logging
import os
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from device_manager import check_online, backup_device, BACKUP_DIR

logger = logging.getLogger(__name__)
scheduler = AsyncIOScheduler()


# ---------------------------------------------------------------------------
# Status check (every 60 s)
# ---------------------------------------------------------------------------

async def check_all_devices():
    from database import SessionLocal, Device, Alert

    db = SessionLocal()
    try:
        devices = db.query(Device).all()
        results = await asyncio.gather(
            *[asyncio.to_thread(check_online, d.ip, d.port) for d in devices],
            return_exceptions=True,
        )
        now = datetime.utcnow()
        for device, online in zip(devices, results):
            if isinstance(online, Exception):
                online = False
            prev_online = device.is_online
            device.is_online = bool(online)
            if device.is_online:
                device.last_seen = now
                # Auto-resolve reachability alerts when device comes back
                db.query(Alert).filter(
                    Alert.device_id == device.id,
                    Alert.category == "reachability",
                    Alert.resolved == False,
                ).update({"resolved": True, "resolved_at": now})
            elif prev_online and not device.is_online:
                # Device just went offline — create reachability alert if none open
                existing = db.query(Alert).filter(
                    Alert.device_id == device.id,
                    Alert.category == "reachability",
                    Alert.resolved == False,
                ).first()
                if not existing:
                    db.add(Alert(
                        device_id=device.id,
                        severity="critical",
                        category="reachability",
                        message="Device went offline",
                    ))

        db.commit()
        online_count = sum(1 for r in results if r is True)
        logger.info("Status check: %d/%d online", online_count, len(devices))
    except Exception as exc:
        logger.error("Status check error: %s", exc)
        db.rollback()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# SNMP poll (every 5 min)
# ---------------------------------------------------------------------------

async def poll_all_snmp():
    from database import SessionLocal, Device, SNMPMetric, Alert
    from snmp_poller import poll_device, evaluate_alerts

    db = SessionLocal()
    try:
        devices = (
            db.query(Device)
            .filter(Device.snmp_enabled == True, Device.is_online == True)
            .all()
        )

        async def _poll(dev):
            return await asyncio.to_thread(
                poll_device,
                dev.ip, dev.port, dev.snmp_port, dev.device_type,
                dev.snmp_security_level, dev.snmp_username,
                dev.snmp_auth_protocol, dev.snmp_auth_password,
                dev.snmp_priv_protocol, dev.snmp_priv_password,
            )

        results = await asyncio.gather(*[_poll(d) for d in devices], return_exceptions=True)
        now = datetime.utcnow()

        for device, metrics in zip(devices, results):
            if isinstance(metrics, Exception):
                logger.error("Poll exception for %s: %s", device.name, metrics)
                continue

            # Store history row
            db.add(SNMPMetric(
                device_id=device.id,
                cpu_percent=metrics["cpu_percent"],
                memory_percent=metrics["memory_percent"],
                latency_ms=metrics["latency_ms"],
                uptime_seconds=metrics["uptime_seconds"],
                interface_count=metrics["interface_count"],
                interfaces_up=metrics["interfaces_up"],
            ))

            # Update denormalised columns on device for fast dashboard reads
            device.last_poll = now
            device.last_cpu_percent = metrics["cpu_percent"]
            device.last_memory_percent = metrics["memory_percent"]
            device.last_latency_ms = metrics["latency_ms"]
            device.last_uptime_seconds = metrics["uptime_seconds"]
            device.last_interface_count = metrics["interface_count"]
            device.last_interfaces_up = metrics["interfaces_up"]
            if metrics["sys_descr"]:
                device.sys_descr = metrics["sys_descr"]

            # Alert evaluation
            active = {
                a.category
                for a in db.query(Alert).filter(
                    Alert.device_id == device.id,
                    Alert.resolved == False,
                ).all()
            }
            to_create, to_resolve = evaluate_alerts(device.id, metrics, active)

            for alert_data in to_create:
                db.add(Alert(**alert_data))

            if to_resolve:
                db.query(Alert).filter(
                    Alert.device_id == device.id,
                    Alert.category.in_(to_resolve),
                    Alert.resolved == False,
                ).update({"resolved": True, "resolved_at": now}, synchronize_session="fetch")

        db.commit()
        logger.info("SNMP poll complete for %d devices", len(devices))

        # Prune metric history: keep last 288 rows per device (24 h at 5-min intervals)
        _prune_metrics(db)

    except Exception as exc:
        logger.error("SNMP poll scheduler error: %s", exc)
        db.rollback()
    finally:
        db.close()


def _prune_metrics(db):
    from database import SNMPMetric, Device
    try:
        for device in db.query(Device).all():
            keep_ids = (
                db.query(SNMPMetric.id)
                .filter(SNMPMetric.device_id == device.id)
                .order_by(SNMPMetric.timestamp.desc())
                .limit(288)
                .subquery()
            )
            db.query(SNMPMetric).filter(
                SNMPMetric.device_id == device.id,
                ~SNMPMetric.id.in_(keep_ids),
            ).delete(synchronize_session=False)
        db.commit()
    except Exception as exc:
        logger.warning("Metric prune error: %s", exc)
        db.rollback()


# ---------------------------------------------------------------------------
# Backup purge (daily — remove files and records older than 30 days)
# ---------------------------------------------------------------------------

BACKUP_RETENTION_DAYS = 30

async def purge_old_backups():
    from database import SessionLocal, Backup
    from datetime import timedelta

    db = SessionLocal()
    try:
        cutoff = datetime.utcnow() - timedelta(days=BACKUP_RETENTION_DAYS)
        old = db.query(Backup).filter(Backup.timestamp < cutoff).all()

        removed_files = 0
        for backup in old:
            fp = os.path.join(BACKUP_DIR, backup.filename)
            if os.path.exists(fp):
                os.remove(fp)
                removed_files += 1
            db.delete(backup)

        db.commit()
        if old:
            logger.info(
                "Backup purge: removed %d records and %d files older than %d days",
                len(old), removed_files, BACKUP_RETENTION_DAYS,
            )
    except Exception as exc:
        logger.error("Backup purge error: %s", exc)
        db.rollback()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Config backup (every 6 h)
# ---------------------------------------------------------------------------

async def backup_all_devices():
    from database import SessionLocal, Device, Backup

    db = SessionLocal()
    try:
        devices = (
            db.query(Device)
            .filter(Device.is_online == True, Device.device_type != "unknown")
            .all()
        )

        async def _do_backup(dev):
            return await asyncio.to_thread(
                backup_device,
                dev.id, dev.ip, dev.username, dev.password,
                dev.port, dev.device_type, dev.name,
            )

        results = await asyncio.gather(*[_do_backup(d) for d in devices], return_exceptions=True)
        now = datetime.utcnow()

        for device, result in zip(devices, results):
            if isinstance(result, Exception):
                success, filename, err = False, f"error_{device.id}.cfg", str(result)
            else:
                success, filename, err = result

            fp = os.path.join(BACKUP_DIR, filename)
            size = os.path.getsize(fp) if os.path.exists(fp) else 0

            db.add(Backup(
                device_id=device.id,
                filename=filename,
                size=size,
                status="success" if success else "failed",
                error_message=err if not success else None,
            ))
            if success:
                device.last_backup = now

        db.commit()
        logger.info("Scheduled backup finished for %d devices", len(devices))
    except Exception as exc:
        logger.error("Backup scheduler error: %s", exc)
        db.rollback()
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Scheduler lifecycle
# ---------------------------------------------------------------------------

def start_scheduler():
    scheduler.add_job(check_all_devices, IntervalTrigger(seconds=60),
                      id="status_check", replace_existing=True)
    scheduler.add_job(poll_all_snmp, IntervalTrigger(minutes=5),
                      id="snmp_poll", replace_existing=True)
    scheduler.add_job(backup_all_devices, IntervalTrigger(hours=6),
                      id="config_backup", replace_existing=True)
    scheduler.add_job(purge_old_backups, IntervalTrigger(hours=24),
                      id="backup_purge", replace_existing=True)
    scheduler.start()
    logger.info("Scheduler started (status 60s | SNMP 5m | backup 6h | purge 24h)")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
