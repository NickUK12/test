"""
SNMP polling engine.

Collects TCP latency, sysUpTime, CPU %, memory %, and interface status
for each device, then evaluates alert thresholds.

Requires: puresnmp >= 2.0
"""

import logging
import socket
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OID constants
# ---------------------------------------------------------------------------

OID_SYS_DESCR          = "1.3.6.1.2.1.1.1.0"
OID_SYS_UPTIME         = "1.3.6.1.2.1.1.3.0"
OID_IF_OPER_STATUS     = "1.3.6.1.2.1.2.2.1.8"   # walk — 1=up 2=down

# Cisco enterprise (IOS / IOS-XE / NX-OS)
OID_CISCO_CPU_5MIN     = "1.3.6.1.4.1.9.9.109.1.1.1.1.8.1"  # 5-min avg %
OID_CISCO_MEM_USED     = "1.3.6.1.4.1.9.9.48.1.1.1.5.1"     # bytes used
OID_CISCO_MEM_FREE     = "1.3.6.1.4.1.9.9.48.1.1.1.6.1"     # bytes free

# Palo Alto enterprise (PAN-COMMON-MIB)
OID_PA_CPU             = "1.3.6.1.4.1.25461.2.1.2.1.3.0"    # CPU util %
OID_PA_MEM             = "1.3.6.1.4.1.25461.2.1.2.1.14.0"   # mem util %

# ---------------------------------------------------------------------------
# Alert thresholds
# ---------------------------------------------------------------------------

THRESHOLDS = {
    "cpu":     {"warning": 80,  "critical": 95},
    "memory":  {"warning": 85,  "critical": 95},
    "latency": {"warning": 100, "critical": 500},   # ms
}


# ---------------------------------------------------------------------------
# TCP latency
# ---------------------------------------------------------------------------

def tcp_latency_ms(ip: str, port: int, timeout: float = 5.0) -> Optional[float]:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        t0 = time.perf_counter()
        err = sock.connect_ex((ip, port))
        elapsed = (time.perf_counter() - t0) * 1000
        sock.close()
        return round(elapsed, 2) if err == 0 else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# puresnmp helpers
# ---------------------------------------------------------------------------

def _make_client(
    ip: str,
    port: int,
    security_level: str,
    username: str,
    auth_protocol: str = "SHA",
    auth_password: str = "",
    priv_protocol: str = "AES",
    priv_password: str = "",
):
    from puresnmp.api.sync import Client
    from puresnmp.credentials import V3, Auth, Priv

    level = security_level.lower()

    if level == "noauthnopriv":
        creds = V3(username)
    elif level == "authnopriv":
        creds = V3(
            username,
            auth=Auth(auth_password, auth_protocol.lower()),
        )
    else:  # authPriv (default)
        creds = V3(
            username,
            auth=Auth(auth_password, auth_protocol.lower()),
            priv=Priv(priv_password, priv_protocol.lower()),
        )

    return Client(ip, creds, port=port, timeout=5)


def _to_python(val) -> Any:
    if val is None:
        return None
    try:
        return int(val)
    except Exception:
        pass
    try:
        return bytes(val).decode("utf-8", errors="replace").strip("\x00").strip()
    except Exception:
        pass
    return str(val)


def _safe_get(client, oid: str) -> Any:
    try:
        return _to_python(client.get(oid))
    except Exception:
        return None


def _safe_walk(client, oid: str) -> List[Tuple[str, Any]]:
    try:
        return [(str(vb.oid), _to_python(vb.value)) for vb in client.walk(oid)]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Main poll function
# ---------------------------------------------------------------------------

def poll_device(
    ip: str,
    ssh_port: int,
    snmp_port: int,
    device_type: str,
    security_level: str,
    username: str,
    auth_protocol: str = "SHA",
    auth_password: str = "",
    priv_protocol: str = "AES",
    priv_password: str = "",
) -> Dict[str, Any]:
    """
    Returns dict of latest metrics. All values are None if unreachable/unconfigured.
    TCP latency is always attempted; SNMP only when credentials are provided.
    """
    ping_port = 443 if device_type == "palo_alto" else ssh_port
    latency = tcp_latency_ms(ip, ping_port)

    result: Dict[str, Any] = {
        "latency_ms":      latency,
        "uptime_seconds":  None,
        "cpu_percent":     None,
        "memory_percent":  None,
        "sys_descr":       None,
        "interface_count": None,
        "interfaces_up":   None,
    }

    if not username:
        return result  # No v3 credentials configured — latency only

    try:
        client = _make_client(
            ip, snmp_port, security_level, username,
            auth_protocol, auth_password, priv_protocol, priv_password,
        )

        # Uptime
        uptime_raw = _safe_get(client, OID_SYS_UPTIME)
        if uptime_raw is not None:
            result["uptime_seconds"] = int(uptime_raw) // 100

        # System description (firmware / OS version)
        result["sys_descr"] = _safe_get(client, OID_SYS_DESCR)
        if result["sys_descr"]:
            result["sys_descr"] = str(result["sys_descr"])[:512]

        # CPU
        if device_type in ("cisco_ios", "cisco_xe", "cisco_nxos"):
            raw = _safe_get(client, OID_CISCO_CPU_5MIN)
            if raw is not None:
                result["cpu_percent"] = float(int(raw))
        elif device_type == "palo_alto":
            raw = _safe_get(client, OID_PA_CPU)
            if raw is not None:
                result["cpu_percent"] = float(int(raw))

        # Memory
        if device_type in ("cisco_ios", "cisco_xe", "cisco_nxos"):
            used = _safe_get(client, OID_CISCO_MEM_USED)
            free = _safe_get(client, OID_CISCO_MEM_FREE)
            if used is not None and free is not None:
                u, f = int(used), int(free)
                total = u + f
                if total > 0:
                    result["memory_percent"] = round(u / total * 100, 1)
        elif device_type == "palo_alto":
            raw = _safe_get(client, OID_PA_MEM)
            if raw is not None:
                result["memory_percent"] = float(int(raw))

        # Interface status walk
        entries = _safe_walk(client, OID_IF_OPER_STATUS)
        if entries:
            result["interface_count"] = len(entries)
            result["interfaces_up"] = sum(1 for _, v in entries if v == 1)

    except ImportError:
        logger.error("puresnmp not installed — run: pip install puresnmp")
    except Exception as exc:
        logger.debug("SNMP poll failed for %s: %s", ip, exc)

    return result


# ---------------------------------------------------------------------------
# Alert evaluation
# ---------------------------------------------------------------------------

def evaluate_alerts(
    device_id: int,
    metrics: Dict[str, Any],
    active_categories: set,
) -> Tuple[List[Dict], List[str]]:
    """
    Returns (alerts_to_create, categories_to_resolve).
    active_categories: set of category strings that currently have open alerts.
    """
    to_create: List[Dict] = []
    to_resolve: List[str] = []

    def _check(category: str, value: Optional[float], label: str):
        if value is None:
            return
        warn = THRESHOLDS[category]["warning"]
        crit = THRESHOLDS[category]["critical"]

        if value >= crit:
            if category not in active_categories:
                to_create.append({
                    "device_id": device_id,
                    "category": category,
                    "severity": "critical",
                    "message": f"{label} critical: {value:.1f}{'%' if category != 'latency' else 'ms'}",
                })
            # Escalate warning → critical by resolving warning first
            elif category in active_categories:
                # Let existing alert stand; only replace if severity changed (handled in scheduler)
                pass
        elif value >= warn:
            if category not in active_categories:
                to_create.append({
                    "device_id": device_id,
                    "category": category,
                    "severity": "warning",
                    "message": f"{label} high: {value:.1f}{'%' if category != 'latency' else 'ms'}",
                })
        else:
            # Condition cleared — resolve any open alert for this category
            if category in active_categories:
                to_resolve.append(category)

    _check("cpu",     metrics.get("cpu_percent"),    "CPU")
    _check("memory",  metrics.get("memory_percent"), "Memory")
    _check("latency", metrics.get("latency_ms"),     "Latency")

    # Interface alert: any interface down
    total = metrics.get("interface_count")
    up    = metrics.get("interfaces_up")
    if total is not None and up is not None and total > 0:
        down = total - up
        if down > 0:
            if "interface" not in active_categories:
                to_create.append({
                    "device_id": device_id,
                    "category": "interface",
                    "severity": "warning",
                    "message": f"{down} interface{'s' if down > 1 else ''} down ({up}/{total} up)",
                })
        else:
            if "interface" in active_categories:
                to_resolve.append("interface")

    return to_create, to_resolve
