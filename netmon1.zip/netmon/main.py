import asyncio
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import BACKUP_DIR, Alert, Backup, Device, SNMPMetric, get_db, init_db
from device_manager import backup_device, check_online, detect_device_type
from scheduler import check_all_devices, poll_all_snmp, start_scheduler, stop_scheduler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    start_scheduler()
    asyncio.create_task(check_all_devices())
    yield
    stop_scheduler()


app = FastAPI(title="NetMon", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class DeviceCreate(BaseModel):
    name: str
    ip: str
    port: int = 22
    username: str
    password: str
    device_type: str = "auto"
    snmp_enabled: bool = True
    snmp_port: int = 161
    snmp_security_level: str = "authPriv"
    snmp_username: str = ""
    snmp_auth_protocol: str = "SHA"
    snmp_auth_password: str = ""
    snmp_priv_protocol: str = "AES"
    snmp_priv_password: str = ""


class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    port: Optional[int] = None
    device_type: Optional[str] = None
    snmp_enabled: Optional[bool] = None
    snmp_port: Optional[int] = None
    snmp_security_level: Optional[str] = None
    snmp_username: Optional[str] = None
    snmp_auth_protocol: Optional[str] = None
    snmp_auth_password: Optional[str] = None
    snmp_priv_protocol: Optional[str] = None
    snmp_priv_password: Optional[str] = None


class DeviceResponse(BaseModel):
    id: int
    name: str
    ip: str
    port: int
    username: str
    device_type: str
    is_online: bool
    last_seen: Optional[datetime]
    last_backup: Optional[datetime]
    created_at: datetime
    snmp_enabled: bool
    snmp_port: int
    snmp_security_level: str
    snmp_username: str
    snmp_auth_protocol: str
    snmp_priv_protocol: str
    last_poll: Optional[datetime]
    last_cpu_percent: Optional[float]
    last_memory_percent: Optional[float]
    last_latency_ms: Optional[float]
    last_uptime_seconds: Optional[int]
    last_interface_count: Optional[int]
    last_interfaces_up: Optional[int]
    sys_descr: Optional[str]
    active_alert_count: int = 0

    model_config = {"from_attributes": True}


class BackupResponse(BaseModel):
    id: int
    device_id: int
    timestamp: datetime
    filename: str
    size: int
    status: str
    error_message: Optional[str]

    model_config = {"from_attributes": True}


class MetricResponse(BaseModel):
    id: int
    device_id: int
    timestamp: datetime
    cpu_percent: Optional[float]
    memory_percent: Optional[float]
    latency_ms: Optional[float]
    uptime_seconds: Optional[int]
    interface_count: Optional[int]
    interfaces_up: Optional[int]

    model_config = {"from_attributes": True}


class AlertResponse(BaseModel):
    id: int
    device_id: int
    device_name: str = ""
    timestamp: datetime
    severity: str
    category: str
    message: str
    resolved: bool
    resolved_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Static / frontend
# ---------------------------------------------------------------------------

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/", response_class=FileResponse)
async def root():
    return FileResponse("static/index.html")


# ---------------------------------------------------------------------------
# Device endpoints
# ---------------------------------------------------------------------------

@app.get("/api/devices", response_model=List[DeviceResponse])
def list_devices(db: Session = Depends(get_db)):
    devices = db.query(Device).order_by(Device.created_at.desc()).all()
    result = []
    for d in devices:
        active = db.query(Alert).filter(
            Alert.device_id == d.id, Alert.resolved == False
        ).count()
        resp = DeviceResponse.model_validate(d)
        resp.active_alert_count = active
        result.append(resp)
    return result


@app.post("/api/devices", response_model=DeviceResponse)
async def add_device(
    payload: DeviceCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    if db.query(Device).filter(Device.ip == payload.ip).first():
        raise HTTPException(400, detail=f"Device with IP {payload.ip} already exists")

    resolved_type = "unknown" if payload.device_type == "auto" else payload.device_type
    device = Device(
        name=payload.name,
        ip=payload.ip,
        port=payload.port,
        username=payload.username,
        password=payload.password,
        device_type=resolved_type,
        snmp_enabled=payload.snmp_enabled,
        snmp_port=payload.snmp_port,
        snmp_security_level=payload.snmp_security_level,
        snmp_username=payload.snmp_username,
        snmp_auth_protocol=payload.snmp_auth_protocol,
        snmp_auth_password=payload.snmp_auth_password,
        snmp_priv_protocol=payload.snmp_priv_protocol,
        snmp_priv_password=payload.snmp_priv_password,
    )
    db.add(device)
    db.commit()
    db.refresh(device)

    if payload.device_type == "auto":
        background_tasks.add_task(_task_detect_and_check, device.id)
    else:
        background_tasks.add_task(_task_check_status, device.id)

    resp = DeviceResponse.model_validate(device)
    resp.active_alert_count = 0
    return resp


@app.patch("/api/devices/{device_id}", response_model=DeviceResponse)
def update_device(device_id: int, payload: DeviceUpdate, db: Session = Depends(get_db)):
    device = _get_device_or_404(device_id, db)
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(device, field, value)
    db.commit()
    db.refresh(device)
    active = db.query(Alert).filter(Alert.device_id == device_id, Alert.resolved == False).count()
    resp = DeviceResponse.model_validate(device)
    resp.active_alert_count = active
    return resp


@app.delete("/api/devices/{device_id}")
def delete_device(device_id: int, db: Session = Depends(get_db)):
    device = _get_device_or_404(device_id, db)
    db.delete(device)
    db.commit()
    return {"message": "Device deleted"}


@app.post("/api/devices/{device_id}/detect")
async def detect_type(
    device_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    _get_device_or_404(device_id, db)
    background_tasks.add_task(_task_detect_and_check, device_id)
    return {"message": "Detection started"}


@app.post("/api/devices/{device_id}/backup")
async def trigger_backup(
    device_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    device = _get_device_or_404(device_id, db)
    if device.device_type == "unknown":
        raise HTTPException(400, detail="Device type unknown — run detection first")
    background_tasks.add_task(_task_backup, device_id)
    return {"message": "Backup started"}


@app.post("/api/devices/{device_id}/poll")
async def trigger_poll(
    device_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    device = _get_device_or_404(device_id, db)
    if not device.snmp_enabled:
        raise HTTPException(400, detail="SNMP is disabled for this device")
    background_tasks.add_task(_task_poll, device_id)
    return {"message": "SNMP poll started"}


# ---------------------------------------------------------------------------
# Backup endpoints
# ---------------------------------------------------------------------------

@app.get("/api/devices/{device_id}/backups", response_model=List[BackupResponse])
def list_backups(device_id: int, db: Session = Depends(get_db)):
    _get_device_or_404(device_id, db)
    return (
        db.query(Backup)
        .filter(Backup.device_id == device_id)
        .order_by(Backup.timestamp.desc())
        .limit(50)
        .all()
    )


@app.get("/api/backups/{backup_id}/download")
def download_backup(backup_id: int, db: Session = Depends(get_db)):
    backup = db.query(Backup).filter(Backup.id == backup_id).first()
    if not backup:
        raise HTTPException(404, detail="Backup not found")
    filepath = os.path.join(BACKUP_DIR, backup.filename)
    if not os.path.exists(filepath):
        raise HTTPException(404, detail="Backup file missing from disk")
    return FileResponse(filepath, filename=backup.filename, media_type="text/plain")


# ---------------------------------------------------------------------------
# Metrics endpoints
# ---------------------------------------------------------------------------

@app.get("/api/devices/{device_id}/metrics", response_model=List[MetricResponse])
def list_metrics(
    device_id: int,
    limit: int = Query(default=48, le=288),
    db: Session = Depends(get_db),
):
    _get_device_or_404(device_id, db)
    return (
        db.query(SNMPMetric)
        .filter(SNMPMetric.device_id == device_id)
        .order_by(SNMPMetric.timestamp.desc())
        .limit(limit)
        .all()
    )


# ---------------------------------------------------------------------------
# Alert endpoints
# ---------------------------------------------------------------------------

@app.get("/api/alerts", response_model=List[AlertResponse])
def list_alerts(
    resolved: Optional[bool] = Query(default=None),
    db: Session = Depends(get_db),
):
    q = db.query(Alert)
    if resolved is not None:
        q = q.filter(Alert.resolved == resolved)
    alerts = q.order_by(Alert.timestamp.desc()).limit(200).all()

    result = []
    for a in alerts:
        resp = AlertResponse.model_validate(a)
        resp.device_name = a.device.name if a.device else ""
        result.append(resp)
    return result


@app.post("/api/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(404, detail="Alert not found")
    alert.resolved = True
    alert.resolved_at = datetime.utcnow()
    db.commit()
    return {"message": "Alert resolved"}


@app.post("/api/alerts/resolve-all")
def resolve_all_alerts(db: Session = Depends(get_db)):
    now = datetime.utcnow()
    db.query(Alert).filter(Alert.resolved == False).update(
        {"resolved": True, "resolved_at": now}, synchronize_session="fetch"
    )
    db.commit()
    return {"message": "All alerts resolved"}


# ---------------------------------------------------------------------------
# Stats endpoint
# ---------------------------------------------------------------------------

@app.get("/api/stats")
def get_stats(db: Session = Depends(get_db)):
    total = db.query(Device).count()
    online = db.query(Device).filter(Device.is_online == True).count()
    backups = db.query(Backup).filter(Backup.status == "success").count()
    active_alerts = db.query(Alert).filter(Alert.resolved == False).count()
    critical_alerts = db.query(Alert).filter(
        Alert.resolved == False, Alert.severity == "critical"
    ).count()
    return {
        "total_devices": total,
        "online": online,
        "offline": total - online,
        "total_backups": backups,
        "active_alerts": active_alerts,
        "critical_alerts": critical_alerts,
    }


# ---------------------------------------------------------------------------
# Background task helpers
# ---------------------------------------------------------------------------

def _get_device_or_404(device_id: int, db: Session) -> Device:
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(404, detail="Device not found")
    return device


async def _task_detect_and_check(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return
        is_online = await asyncio.to_thread(check_online, device.ip, device.port)
        device.is_online = is_online
        if is_online:
            device.last_seen = datetime.utcnow()
            detected = await asyncio.to_thread(
                detect_device_type, device.ip, device.username, device.password, device.port
            )
            device.device_type = detected
            logger.info("Detected %s (%s) → %s", device.name, device.ip, detected)
        db.commit()
    except Exception as exc:
        logger.error("Detect-and-check failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()


async def _task_check_status(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return
        is_online = await asyncio.to_thread(check_online, device.ip, device.port)
        device.is_online = is_online
        if is_online:
            device.last_seen = datetime.utcnow()
        db.commit()
    except Exception as exc:
        logger.error("Status check failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()


async def _task_backup(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return
        success, filename, err = await asyncio.to_thread(
            backup_device,
            device.id, device.ip, device.username, device.password,
            device.port, device.device_type, device.name,
        )
        fp = os.path.join(BACKUP_DIR, filename)
        size = os.path.getsize(fp) if os.path.exists(fp) else 0
        db.add(Backup(
            device_id=device.id, filename=filename, size=size,
            status="success" if success else "failed",
            error_message=err if not success else None,
        ))
        if success:
            device.last_backup = datetime.utcnow()
        db.commit()
        logger.info("Manual backup %s for %s", "succeeded" if success else "failed", device.name)
    except Exception as exc:
        logger.error("Backup task failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()


async def _task_poll(device_id: int):
    from database import SessionLocal, SNMPMetric, Alert
    from snmp_poller import poll_device, evaluate_alerts

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return

        metrics = await asyncio.to_thread(
            poll_device,
            device.ip, device.port, device.snmp_port, device.device_type,
            device.snmp_security_level, device.snmp_username,
            device.snmp_auth_protocol, device.snmp_auth_password,
            device.snmp_priv_protocol, device.snmp_priv_password,
        )
        now = datetime.utcnow()

        db.add(SNMPMetric(
            device_id=device.id,
            cpu_percent=metrics["cpu_percent"],
            memory_percent=metrics["memory_percent"],
            latency_ms=metrics["latency_ms"],
            uptime_seconds=metrics["uptime_seconds"],
            interface_count=metrics["interface_count"],
            interfaces_up=metrics["interfaces_up"],
        ))

        device.last_poll = now
        device.last_cpu_percent = metrics["cpu_percent"]
        device.last_memory_percent = metrics["memory_percent"]
        device.last_latency_ms = metrics["latency_ms"]
        device.last_uptime_seconds = metrics["uptime_seconds"]
        device.last_interface_count = metrics["interface_count"]
        device.last_interfaces_up = metrics["interfaces_up"]
        if metrics["sys_descr"]:
            device.sys_descr = metrics["sys_descr"]

        active = {
            a.category
            for a in db.query(Alert).filter(
                Alert.device_id == device.id, Alert.resolved == False
            ).all()
        }
        to_create, to_resolve = evaluate_alerts(device.id, metrics, active)
        for alert_data in to_create:
            db.add(Alert(**alert_data))
        if to_resolve:
            db.query(Alert).filter(
                Alert.device_id == device.id,
                Alert.category.in_(to_resolve),
                Alert.resolved == False,
            ).update({"resolved": True, "resolved_at": now}, synchronize_session="fetch")

        db.commit()
        logger.info("Manual SNMP poll complete for %s", device.name)
    except Exception as exc:
        logger.error("SNMP poll task failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()
