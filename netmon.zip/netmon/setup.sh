#!/bin/bash
set -e

echo "==> Setting up NetMon virtual environment..."
python3 -m venv venv
source venv/bin/activate

echo "==> Installing dependencies..."
pip install --upgrade pip -q
pip install -r requirements.txt

echo ""
echo "✓ Setup complete!"
echo ""
echo "To start NetMon:"
echo "  ./start.sh"
echo ""
echo "Then open: http://localhost:8080"
