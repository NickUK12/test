import asyncio
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import BACKUP_DIR, Backup, Device, get_db, init_db
from device_manager import backup_device, check_online, detect_device_type
from scheduler import check_all_devices, start_scheduler, stop_scheduler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    start_scheduler()
    asyncio.create_task(check_all_devices())
    yield
    stop_scheduler()


app = FastAPI(title="NetMon", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class DeviceCreate(BaseModel):
    name: str
    ip: str
    port: int = 22
    username: str
    password: str
    device_type: str = "auto"  # auto | cisco_ios | cisco_nxos | cisco_xe | palo_alto


class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    port: Optional[int] = None
    device_type: Optional[str] = None


class DeviceResponse(BaseModel):
    id: int
    name: str
    ip: str
    port: int
    username: str
    device_type: str
    is_online: bool
    last_seen: Optional[datetime]
    last_backup: Optional[datetime]
    created_at: datetime

    model_config = {"from_attributes": True}


class BackupResponse(BaseModel):
    id: int
    device_id: int
    timestamp: datetime
    filename: str
    size: int
    status: str
    error_message: Optional[str]

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Static / frontend
# ---------------------------------------------------------------------------

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/", response_class=FileResponse)
async def root():
    return FileResponse("static/index.html")


# ---------------------------------------------------------------------------
# Device endpoints
# ---------------------------------------------------------------------------

@app.get("/api/devices", response_model=List[DeviceResponse])
def list_devices(db: Session = Depends(get_db)):
    return db.query(Device).order_by(Device.created_at.desc()).all()


@app.post("/api/devices", response_model=DeviceResponse)
async def add_device(
    payload: DeviceCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    if db.query(Device).filter(Device.ip == payload.ip).first():
        raise HTTPException(400, detail=f"Device with IP {payload.ip} already exists")

    resolved_type = "unknown" if payload.device_type == "auto" else payload.device_type
    device = Device(
        name=payload.name,
        ip=payload.ip,
        port=payload.port,
        username=payload.username,
        password=payload.password,
        device_type=resolved_type,
    )
    db.add(device)
    db.commit()
    db.refresh(device)

    if payload.device_type == "auto":
        background_tasks.add_task(_task_detect_and_check, device.id)
    else:
        background_tasks.add_task(_task_check_status, device.id)

    return device


@app.patch("/api/devices/{device_id}", response_model=DeviceResponse)
def update_device(device_id: int, payload: DeviceUpdate, db: Session = Depends(get_db)):
    device = _get_device_or_404(device_id, db)
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(device, field, value)
    db.commit()
    db.refresh(device)
    return device


@app.delete("/api/devices/{device_id}")
def delete_device(device_id: int, db: Session = Depends(get_db)):
    device = _get_device_or_404(device_id, db)
    db.delete(device)
    db.commit()
    return {"message": "Device deleted"}


@app.post("/api/devices/{device_id}/detect")
async def detect_type(
    device_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    _get_device_or_404(device_id, db)
    background_tasks.add_task(_task_detect_and_check, device_id)
    return {"message": "Detection started"}


@app.post("/api/devices/{device_id}/backup")
async def trigger_backup(
    device_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    device = _get_device_or_404(device_id, db)
    if device.device_type == "unknown":
        raise HTTPException(400, detail="Device type unknown — run detection first")
    background_tasks.add_task(_task_backup, device_id)
    return {"message": "Backup started"}


# ---------------------------------------------------------------------------
# Backup endpoints
# ---------------------------------------------------------------------------

@app.get("/api/devices/{device_id}/backups", response_model=List[BackupResponse])
def list_backups(device_id: int, db: Session = Depends(get_db)):
    _get_device_or_404(device_id, db)
    return (
        db.query(Backup)
        .filter(Backup.device_id == device_id)
        .order_by(Backup.timestamp.desc())
        .limit(50)
        .all()
    )


@app.get("/api/backups/{backup_id}/download")
def download_backup(backup_id: int, db: Session = Depends(get_db)):
    backup = db.query(Backup).filter(Backup.id == backup_id).first()
    if not backup:
        raise HTTPException(404, detail="Backup not found")
    filepath = os.path.join(BACKUP_DIR, backup.filename)
    if not os.path.exists(filepath):
        raise HTTPException(404, detail="Backup file missing from disk")
    return FileResponse(filepath, filename=backup.filename, media_type="text/plain")


# ---------------------------------------------------------------------------
# Stats endpoint
# ---------------------------------------------------------------------------

@app.get("/api/stats")
def get_stats(db: Session = Depends(get_db)):
    total = db.query(Device).count()
    online = db.query(Device).filter(Device.is_online == True).count()
    backups = db.query(Backup).filter(Backup.status == "success").count()
    return {
        "total_devices": total,
        "online": online,
        "offline": total - online,
        "total_backups": backups,
    }


# ---------------------------------------------------------------------------
# Background task helpers
# ---------------------------------------------------------------------------

def _get_device_or_404(device_id: int, db: Session) -> Device:
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(404, detail="Device not found")
    return device


async def _task_detect_and_check(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return

        is_online = await asyncio.to_thread(check_online, device.ip, device.port)
        device.is_online = is_online
        if is_online:
            device.last_seen = datetime.utcnow()

        if is_online:
            detected = await asyncio.to_thread(
                detect_device_type, device.ip, device.username, device.password, device.port
            )
            device.device_type = detected
            logger.info("Detected %s (%s) → %s", device.name, device.ip, detected)

        db.commit()
    except Exception as exc:
        logger.error("Detect-and-check failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()


async def _task_check_status(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return
        is_online = await asyncio.to_thread(check_online, device.ip, device.port)
        device.is_online = is_online
        if is_online:
            device.last_seen = datetime.utcnow()
        db.commit()
    except Exception as exc:
        logger.error("Status check failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()


async def _task_backup(device_id: int):
    from database import SessionLocal

    db = SessionLocal()
    try:
        device = db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return

        success, filename, err = await asyncio.to_thread(
            backup_device,
            device.id, device.ip, device.username, device.password,
            device.port, device.device_type, device.name,
        )

        fp = os.path.join(BACKUP_DIR, filename)
        size = os.path.getsize(fp) if os.path.exists(fp) else 0

        db.add(Backup(
            device_id=device.id,
            filename=filename,
            size=size,
            status="success" if success else "failed",
            error_message=err if not success else None,
        ))

        if success:
            device.last_backup = datetime.utcnow()

        db.commit()
        logger.info("Manual backup %s for %s", "succeeded" if success else "failed", device.name)
    except Exception as exc:
        logger.error("Backup task failed for device %d: %s", device_id, exc)
        db.rollback()
    finally:
        db.close()
