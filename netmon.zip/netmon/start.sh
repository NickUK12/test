#!/bin/bash
set -e

cd "$(dirname "$0")"

if [ ! -d "venv" ]; then
  echo "Run ./setup.sh first"
  exit 1
fi

source venv/bin/activate
echo "Starting NetMon on http://0.0.0.0:8080 ..."
uvicorn main:app --host 0.0.0.0 --port 8080
