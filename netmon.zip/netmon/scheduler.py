import asyncio
import logging
import os
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from device_manager import check_online, backup_device, BACKUP_DIR

logger = logging.getLogger(__name__)
scheduler = AsyncIOScheduler()


async def check_all_devices():
    from database import SessionLocal, Device

    db = SessionLocal()
    try:
        devices = db.query(Device).all()
        results = await asyncio.gather(
            *[asyncio.to_thread(check_online, d.ip, d.port) for d in devices],
            return_exceptions=True,
        )
        now = datetime.utcnow()
        for device, online in zip(devices, results):
            if isinstance(online, Exception):
                online = False
            device.is_online = bool(online)
            if device.is_online:
                device.last_seen = now
        db.commit()
        online_count = sum(1 for r in results if r is True)
        logger.info("Status check: %d/%d online", online_count, len(devices))
    except Exception as exc:
        logger.error("Status check error: %s", exc)
        db.rollback()
    finally:
        db.close()


async def backup_all_devices():
    from database import SessionLocal, Device, Backup

    db = SessionLocal()
    try:
        devices = (
            db.query(Device)
            .filter(Device.is_online == True, Device.device_type != "unknown")
            .all()
        )

        async def _do_backup(dev):
            return await asyncio.to_thread(
                backup_device,
                dev.id, dev.ip, dev.username, dev.password,
                dev.port, dev.device_type, dev.name,
            )

        results = await asyncio.gather(*[_do_backup(d) for d in devices], return_exceptions=True)
        now = datetime.utcnow()

        for device, result in zip(devices, results):
            if isinstance(result, Exception):
                success, filename, err = False, f"error_{device.id}.cfg", str(result)
            else:
                success, filename, err = result

            size = 0
            fp = os.path.join(BACKUP_DIR, filename)
            if os.path.exists(fp):
                size = os.path.getsize(fp)

            db.add(Backup(
                device_id=device.id,
                filename=filename,
                size=size,
                status="success" if success else "failed",
                error_message=err if not success else None,
            ))
            if success:
                device.last_backup = now

        db.commit()
        logger.info("Scheduled backup finished for %d devices", len(devices))
    except Exception as exc:
        logger.error("Backup scheduler error: %s", exc)
        db.rollback()
    finally:
        db.close()


def start_scheduler():
    scheduler.add_job(check_all_devices, IntervalTrigger(seconds=60),
                      id="status_check", replace_existing=True)
    scheduler.add_job(backup_all_devices, IntervalTrigger(hours=6),
                      id="config_backup", replace_existing=True)
    scheduler.start()
    logger.info("Scheduler started (status every 60s, backup every 6h)")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
