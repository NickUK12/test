from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from datetime import datetime
import os

DATABASE_URL = "sqlite:///./netmon.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

BACKUP_DIR = "./backups"
os.makedirs(BACKUP_DIR, exist_ok=True)


class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    ip = Column(String, nullable=False, unique=True)
    port = Column(Integer, default=22)
    username = Column(String, nullable=False)
    password = Column(String, nullable=False)
    # cisco_ios | cisco_nxos | cisco_xe | palo_alto | unknown
    device_type = Column(String, default="unknown")
    is_online = Column(Boolean, default=False)
    last_seen = Column(DateTime, nullable=True)
    last_backup = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    backups = relationship("Backup", back_populates="device", cascade="all, delete-orphan")


class Backup(Base):
    __tablename__ = "backups"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    filename = Column(String, nullable=False)
    size = Column(Integer, default=0)
    status = Column(String, default="success")  # success | failed
    error_message = Column(Text, nullable=True)

    device = relationship("Device", back_populates="backups")


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
